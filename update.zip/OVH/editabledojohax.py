tchoice = True
while tchoice:
    absoultely_unused_variable = os.system(clearscreen)
    print("""
Welcome to Editable DojoHax! Select a weapon/gear set to get started!
Editable DojoHax by MCMiners9 (aka SplatTim)

<1> Naked Inkling + Gold Dynamo Roller
<2> Octoling Seaweed Hair + Octoshot Replica
<3> Hero Armor + Hero Roller
<4> Hero gear + Hero shot
<5> Squid Research Lab gear + Carbon Roller Deco
""")
    tchoice = raw_input(">> ")

    if tchoice == "1":
        from tcpgecko import tcpgecko
        tcp = TCPGecko(ip)

        tcp.pokemem(headgear id, headgear id )
        tcp.pokemem(clothing id, clothing id )
        tcp.pokemem(shoes id, shoes id )
        tcp.pokemem(weapon id, weapon id)

        tcp.s.close()
        print("Done")

    elif choice == "2":
        from tcpgecko import tcpgecko
        tcp = TCPGecko(ip)

        tcp.pokemem(headgear id, headgear id )
        tcp.pokemem(clothing id, clothing id )
        tcp.pokemem(shoes id, shoes id )
        tcp.pokemem(weapon id, weapon id )

        tcp.s.close()
        print("Done")

    elif choice == "3":
        from tcpgecko import tcpgecko
        tcp = TCPGecko(ip)

        tcp.pokemem(hats = {0x0000697c : [0x00000007, 0x00000007, 0x00000008]} )
        tcp.pokemem(clothes = {0x0000697c : [0x00000008, 0x00000003, 0x00000006]} )
        tcp.pokemem(shoes = {0x0000697c : [0x00000005, 0x00000003, 0x00000006]} )
        tcp.pokemem(000007DF, 000007DF )

        tcp.s.close()
        print("Done")

    elif choice == "4":
        from tcpgecko import tcpgecko
        tcp = TCPGecko(ip)

        tcp.pokemem(headgear id, headgear id )
        tcp.pokemem(clothing id, clothing id )
        tcp.pokemem(shoes id, shoes id )
        tcp.pokemem(weapon id, weapon id )

        tcp.s.close()
        print("Done")

    elif choice "5":
        from tcpgecko import tcpgecko
        tcp = TCPGecko(ip)

        tcp.pokemem(headgear id, headgear id )
        tcp.pokemem(clothing id, clothing id )
        tcp.pokemem(shoes id, shoes id )
        tcp.pokemem(weapon id, weapon id)

        tcp.s.close()
        print("Done")
