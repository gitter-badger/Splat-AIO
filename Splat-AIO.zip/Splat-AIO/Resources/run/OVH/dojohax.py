from tcpgecko import TCPGecko
 
tcp = TCPGecko(ip)
 
#remove weapon data
tcp.pokemem(0x12CAEA74+0x1000, 0x00000000)
tcp.pokemem(0x12CAEA78+0x1000, 0x00000000)
tcp.pokemem(0x12CAEBB0+0x1000, 0x00000000)
tcp.pokemem(0x12CAEBB4+0x1000, 0x00000000)
tcp.pokemem(0x12CAECEC+0x1000, 0x00000000)
tcp.pokemem(0x12CAECF0+0x1000, 0x00000000)
tcp.pokemem(0x12CAEE28+0x1000, 0x00000000)
tcp.pokemem(0x12CAEE2C+0x1000, 0x00000000)
tcp.pokemem(0x12CAEF64+0x1000, 0x00000000)
tcp.pokemem(0x12CAF0A0+0x1000, 0x00000000)
tcp.pokemem(0x12CAF1DC+0x1000, 0x00000000)
tcp.pokemem(0x12CAF1E0+0x1000, 0x00000000)
tcp.pokemem(0x12CAF318+0x1000, 0x00000000)
tcp.pokemem(0x12CAF31C+0x1000, 0x00000000)
 
#remove gear data
tcp.pokemem(0x12CAEABC+0x1000, 0x00000000)
tcp.pokemem(0x12CAEB08+0x1000, 0x00000000)
tcp.pokemem(0x12CAEB54+0x1000, 0x00000000)
tcp.pokemem(0x12CAEBF8+0x1000, 0x00000000)
tcp.pokemem(0x12CAEC44+0x1000, 0x00000000)
tcp.pokemem(0x12CAEC90+0x1000, 0x00000000)
tcp.pokemem(0x12CAED34+0x1000, 0x00000000)
tcp.pokemem(0x12CAED80+0x1000, 0x00000000)
tcp.pokemem(0x12CAEDCC+0x1000, 0x00000000)
tcp.pokemem(0x12CAEE70+0x1000, 0x00000000)
tcp.pokemem(0x12CAEEBC+0x1000, 0x00000000)
tcp.pokemem(0x12CAEF08+0x1000, 0x00000000)
tcp.pokemem(0x12CAEFAC+0x1000, 0x00000000)
tcp.pokemem(0x12CAEFF8+0x1000, 0x00000000)
tcp.pokemem(0x12CAF044+0x1000, 0x00000000)
tcp.pokemem(0x12CAF0E8+0x1000, 0x00000000)
tcp.pokemem(0x12CAF134+0x1000, 0x00000000)
tcp.pokemem(0x12CAF180+0x1000, 0x00000000)
tcp.pokemem(0x12CAF224+0x1000, 0x00000000)
tcp.pokemem(0x12CAF270+0x1000, 0x00000000)
tcp.pokemem(0x12CAF2BC+0x1000, 0x00000000)
tcp.pokemem(0x12CAF360+0x1000, 0x00000000)
tcp.pokemem(0x12CAF3AC+0x1000, 0x00000000)
tcp.pokemem(0x12CAF3F8+0x1000, 0x00000000)
 
#replace with desired sets
tcp.writestr(0x12CAEA6C+0x1000, b"Charge_Long00") #slot 0 weapon, E-liter 3K
tcp.writestr(0x12CAEAB8+0x1000, b"SUP001") #slot 0 head, SRL
tcp.writestr(0x12CAEB04+0x1000, b"SUP001") #slot 0 clothes, SRL
tcp.writestr(0x12CAEB50+0x1000, b"SUP001") #slot 0 shoes, SRL
tcp.writestr(0x12CAEBA8+0x1000, b"Roller_Compact01") #slot 1 weapon, Carbon Roller Deco
tcp.writestr(0x12CAEBF4+0x1000, b"SUP001") #slot 1 head, SRL
tcp.writestr(0x12CAEC40+0x1000, b"SUP001") #slot 1 clothes, SRL
tcp.writestr(0x12CAEC8C+0x1000, b"SUP001") #slot 1 shoes, SRL
tcp.writestr(0x12CAECE4+0x1000, b"Roller_BrushMini02") #slot 2 weapon, Permanent Inkbrush
tcp.writestr(0x12CAED30+0x1000, b"SUP001") #slot 2 head, SRL
tcp.writestr(0x12CAED7C+0x1000, b"SUP001") #slot 2 clothes, SRL
tcp.writestr(0x12CAEDC8+0x1000, b"SUP001") #slot 2 shoes, SRL
tcp.writestr(0x12CAEE20+0x1000, b"Roller_BrushMini00") #slot 3 weapon, Inkbrush
tcp.writestr(0x12CAEE6C+0x1000, b"SUP001") #slot 3 head, SRL
tcp.writestr(0x12CAEEB8+0x1000, b"SUP001") #slot 3 clothes, SRL
tcp.writestr(0x12CAEF04+0x1000, b"SUP001") #slot 3 shoes, SRL
tcp.writestr(0x12CAEF5C+0x1000, b"Shot_QuickMiddle01") #slot 4 weapon, N-ZAP '89
tcp.writestr(0x12CAEFA8+0x1000, b"SUP001") #slot 4 head, SRL
tcp.writestr(0x12CAEFF4+0x1000, b"SUP001") #slot 4 clothes, SRL
tcp.writestr(0x12CAF040+0x1000, b"SUP001") #slot 4 shoes, SRL
tcp.writestr(0x12CAF098+0x1000, b"Gatling_Standard01") #slot 5 weapon, Heavy Splatling Deco
tcp.writestr(0x12CAF0E4+0x1000, b"SUP001") #slot 5 head, SRL
tcp.writestr(0x12CAF130+0x1000, b"SUP001") #slot 5 clothes, SRL
tcp.writestr(0x12CAF17C+0x1000, b"SUP001") #slot 5 shoes, SRL
tcp.writestr(0x12CAF1D4+0x1000, b"BigBall_Diffusion00") #slot 6 weapon, Tri-Slosher
tcp.writestr(0x12CAF220+0x1000, b"SUP001") #slot 6 head, SRL
tcp.writestr(0x12CAF26C+0x1000, b"SUP001") #slot 6 clothes, SRL
tcp.writestr(0x12CAF2B8+0x1000, b"SUP001") #slot 6 shoes, SRL
tcp.writestr(0x12CAF310+0x1000, b"Roller_Normal02") #slot 7 weapon, CoroCoro Splat Roller
tcp.writestr(0x12CAF35C+0x1000, b"SUP001") #slot 7 head, SRL
tcp.writestr(0x12CAF3A8+0x1000, b"SUP001") #slot 7 clothes, SRL
tcp.writestr(0x12CAF3F4+0x1000, b"SUP001") #slot 7 shoes, SRL
 
tcp.s.close()
print("Done.")
