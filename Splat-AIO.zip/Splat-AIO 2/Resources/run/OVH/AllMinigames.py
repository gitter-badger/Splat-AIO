
#Credit to Riru2025
#Unlocks all minigames (Splatoon 2.8.0, OVH Gecko)

tcp = TCPGecko(ip)
tcp.pokemem(0x12CD1C40 + diff, 0x000F0000)
tcp.s.close()
print("Done.")
