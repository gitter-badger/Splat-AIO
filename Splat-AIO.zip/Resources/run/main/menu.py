#Menu, in hopes that os.system() will function properly
geckoent = 1
cver = int(open("./Resources/setup/ver.txt", "r").read())
choice = True
while choice:
    absolutely_unsigned_variable = os.system("cls")
    print("Splat AIO v%d (for Splatoon 2.9) -- Wii U IP: %s" % (cver, ip))
    print("Original AIO by iAqua, rewritten by seresaa, edits by Deck of Noobs")
    print("""
Please don't just blindly use these hacks. Your chances of getting banned
vary depending on which of these hacks you use and how you use them.
Some of these may not function on future updates, and if so,
wait until they're updated.
""")
    print("Please press a button followed by ENTER:")
    print("""
<1> Octohax+                        <g> Gecko Map Tester
<2> Octohax+, with  Octo Form       <a> Amiibohax
                                    <b> Colorizer (Requires Java, Broken)
<3> Set Money                       <c> Splathax
<4> Set Snails                      <s> Sisterhax
<5> Set Level                       <m> Music Randomizer (Cafiine only)
<6> Set Rank                        <t> TCPGecko.NET
<7> All (Safely) Obtainable Gear    <i> Scan for IP         
<8> All Obtainable Weapons          <v> Options
<9> Unlock All Arcade Games         <n> Tools

                                    <ENTER> Exit\n\n""")
    
    choice = raw_input(">> ")

    #Squidform Octohax
    if choice == "1":
        if geckoent == 1:
            execfile("./Resources/run/OVH/octohax+.py")
        else:
            execfile("./Resources/run/HBL/octohax+.py")

    #Octoform Octohax so people stop saying it doesn't work.
    elif choice == "2":
        if geckoent == 1:
            execfile("./Resources/run/OVH/octocto+.py")
        else:
            execfile("./Resources/run/HBL/octocto+.py")

    #Max Money.
    elif choice == "3":
        if geckoent == 1:
            execfile("./Resources/run/OVH/money.py")
        else:
            execfile("./Resources/run/HBL/money.py")

    #Max Snails.
    elif choice == "4":
        if geckoent == 1:
            execfile("./Resources/run/OVH/Snails.py")
        else:
            execfile("./Resources/run/HBL/Snails.py")

    #Level 50.
    elif choice == "5":
        if geckoent == 1:
            execfile("./Resources/run/OVH/MaxStats1.py")
        else:
            execfile("./Resources/run/HBL/MaxStats1.py")

    #S+ 99
    elif choice == "6":
        if geckoent == 1:
            execfile("./Resources/run/OVH/MaxStats2.py")
        else:
            execfile("./Resources/run/HBL/MaxStats2.py")

    #All Gear.
    elif choice == "7":
        if geckoent == 1:
            execfile("./Resources/run/OVH/AllGear.py")
        else:
            execfile("./Resources/run/HBL/AllGear.py")

    #All Weapons.
    elif choice == "8":
        if geckoent == 1:
            execfile("./Resources/run/OVH/Weapons.py")
        else:
            #execfile("./Resources/run/HBL/Weapons.py")
            pass

    #All Minigames.
    elif choice == "9":
        if geckoent == 1:
            execfile("./Resources/run/OVH/AllMinigames.py")
        else:
            execfile("./Resources/run/HBL/AllMinigames.py")

    #amiibohax
    elif choice == "a":
    
        subprocess.call("./Resources/run/exe/amiibohax.exe")
        

    #Instaban. Don't use this, you'll get banned.
    elif choice == "b":
            os.system(r".\Resources\run\exe\gudWrapper.jar .\Resources\run\exe\SplatoonColorizer.28.gud")
            

    #SplatHax
    elif choice == "c":
        subprocess.call("./Resources/run/exe/Splathax.exe")

    #TCPGecko
    elif choice == "t":
        if geckoent == 1:
            subprocess.call("./Resources/run/Gecko/Gecko_dNet.exe")
        else:
            absolutely_unused_variable = os.system("cls")
            print("""Note: The Homebrew Launcher version of TCPGecko is not the same as
the loadiine.ovh version. If you can't find an address you know,
first try adding 0x9000 onto it. e.g. 12CD0D80 becomes 12CD9D80""")
            subprocess.call("./Resources/run/Gecko/Gecko_dNet.exe")

    #IP Scanner
    elif choice == "i":
        subprocess.call("./Resources/run/exe/ipscan24.exe")

    #Options
    elif choice == "v":
        execfile("./Resources/run/main/options.py")

    #Tools
    elif choice == "n":
        execfile("./Resources/run/main/tools.py")

    #Sisterhax
    elif choice == "s":
        execfile("./Resources/run/extra/sisterhax.py")

    #Music Randomizer
    elif choice == "m":
        subprocess.call("./Resources/run/exe/MusicRandomizer.exe")

    #Map Tester
    elif choice == "g":
        subprocess.call("./Resources/run/exe/GeckoMapTester.exe")
